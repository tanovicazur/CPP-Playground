#include "Botlich.hpp"

int main()
{
    Botlich b;

    b.check("[((<>())<<>>)()<>]");
    b.check("[[[<>()]]]");
}
